"""lab5 controller."""
from controller import Robot, Motor, Camera, RangeFinder, Lidar, Keyboard
import math
import numpy as np
from matplotlib import pyplot as plt
from scipy.signal import convolve2d # Uncomment if you want to use something else for finding the configuration space
import sys

MAX_SPEED = 7.0  # [rad/s]
MAX_SPEED_MS = 0.633 # [m/s]
AXLE_LENGTH = 0.4044 # m
MOTOR_LEFT = 10
MOTOR_RIGHT = 11
N_PARTS = 12

LIDAR_ANGLE_BINS = 667
LIDAR_SENSOR_MAX_RANGE = 2.75 # Meters
LIDAR_ANGLE_RANGE = math.radians(240)

SMALL_MAP_INCREMENT_CONSTANT = 12e-3

# Node class for A* search.
# class structure taken from: https://medium.com/@nicholas.w.swift/easy-a-star-pathfinding-7e6689c7f7b2
class Node():
    """
    constructor of node class, stores:
    parent: its parent node.
    position: where it is located.
    step_count: how many steps it took to reach this goal.
    heuristic: its heuristic.
    pos_val: positional value based on the heuristic and step count combined.
    """
    def __init__(self, parent=None, position=None):
        self.parent = parent
        self.position = position
        self.step_count = 0
        self.heuristic = 0
        self.pos_val = 0

    #used for accurate and convenient comparison between seperate node positions.
    def __eq__(self, other):
        return self.position == other.position

##### vvv [Begin] Do Not Modify vvv #####
# create the Robot instance.
print("here1",flush = True)
sys.stdout.flush()
robot = Robot()
print("here2",flush = True)
sys.stdout.flush()
# get the time step of the current world.
timestep = int(robot.getBasicTimeStep())

# The Tiago robot has multiple motors, each identified by their names below
part_names = ("head_2_joint", "head_1_joint", "torso_lift_joint", "arm_1_joint",
              "arm_2_joint",  "arm_3_joint",  "arm_4_joint",      "arm_5_joint",
              "arm_6_joint",  "arm_7_joint",  "wheel_left_joint", "wheel_right_joint")

# All motors except the wheels are controlled by position control. The wheels
# are controlled by a velocity controller. We therefore set their position to infinite.
target_pos = (0.0, 0.0, 0.09, 0.07, 1.02, -3.16, 1.27, 1.32, 0.0, 1.41, 'inf', 'inf')
robot_parts=[]

for i in range(N_PARTS):
    robot_parts.append(robot.getDevice(part_names[i]))
    robot_parts[i].setPosition(float(target_pos[i]))
    robot_parts[i].setVelocity(robot_parts[i].getMaxVelocity() / 2.0)

# The Tiago robot has a couple more sensors than the e-Puck
# Some of them are mentioned below. We will use its LiDAR for Lab 5

# range = robot.getDevice('range-finder')
# range.enable(timestep)
# camera = robot.getDevice('camera')
# camera.enable(timestep)
# camera.recognitionEnable(timestep)
lidar = robot.getDevice('Hokuyo URG-04LX-UG01')
lidar.enable(timestep)
lidar.enablePointCloud()

# We are using a GPS and compass to disentangle mapping and localization
gps = robot.getDevice("gps")
gps.enable(timestep)
compass = robot.getDevice("compass")
compass.enable(timestep)

# We are using a keyboard to remote control the robot
keyboard = robot.getKeyboard()
keyboard.enable(timestep)

# The display is used to display the map. We are using 360x360 pixels to
# map the 12x12m2 apartment
display = robot.getDevice("display")

# Odometry
pose_x     = 0
pose_y     = 0
pose_theta = 0

vL = 0
vR = 0

lidar_sensor_readings = [] # List to hold sensor readings
lidar_offsets = np.linspace(-LIDAR_ANGLE_RANGE/2., +LIDAR_ANGLE_RANGE/2., LIDAR_ANGLE_BINS)
lidar_offsets = lidar_offsets[83:len(lidar_offsets)-83] # Only keep lidar readings not blocked by robot chassis

map = None
##### ^^^ [End] Do Not Modify ^^^ #####

##################### IMPORTANT #####################
# Set the mode here. Please change to 'autonomous' before submission
# mode = 'manual' # Part 1.1: manual mode
mode = 'planner'
# mode = 'autonomous'



###################
#
# Planner
#
###################
if mode == 'planner':
    # Part 2.3: Provide start and end in world coordinate frame and convert it to map's frame
    start_w = (4.47,8.07) # (Pose_X, Pose_Z) in meters
    end_w = (10.0,7.0) # (Pose_X, Pose_Z) in meters

    # Convert the start_w and end_w from the webots coordinate frame into the map frame
    start = (134,242) # (x, y) in 360x360 map
    end = (300,210) # (x, y) in 360x360 map

    # node sorting function for finding the next node to explore.
    def nodeSort(node):
      return node.pos_val

    # Part 2.3: Implement A* or Dijkstra's Algorithm to find a path
    # inspiration taken from: https://medium.com/@nicholas.w.swift/easy-a-star-pathfinding-7e6689c7f7b2
    """
        :param map: A 2D numpy array of size 360x360 representing the world's cspace with 0 as free space and 1 as obstacle
        :param start: A tuple of indices representing the start cell in the map
        :param end: A tuple of indices representing the end cell in the map
        :return: A list of tuples as a path from the given start to the given end in the given maze
        """
    def path_planner(map, start, end):
        print("here3",flush = True)
        sys.stdout.flush()
        start_node = Node(None,start)
        end_node = Node(None, end)
        explore_set = [start_node]
        complete_set = []
        while len(explore_set) > 0:
            #sorts to find the node with the lowest path cost.
            explore_set.sort(key=nodeSort)
            #gets the next node to explore and adds it the complete set.
            explore_node = explore_set.pop(0)
            complete_set.append(explore_node)
            #check if you reached the goal.
            if explore_node == end_node:
                path = []
                while explore_node is not None:
                    path.append(explore_node.position)
                    explore_node = explore_node.parent
                return path.reverse() 
            #generate children.
            child_set = []
            for new_position in [(0, -1), (0, 1), (-1, 0), (1, 0), (-1, -1), (-1, 1), (1, -1), (1, 1)]:
                node_pos = (explore_node.position[0]+new_position[0],explore_node.position[1]+new_position[1])
                #print(node_pos[0], node_pos[1])
                if node_pos[0] >= 0 and node_pos[0] < len(map) and node_pos[1] >= 0 and node_pos[1] < len(map[0]) and map[node_pos[0]][node_pos[1]] == 0:
                    child = Node(explore_node,node_pos)
                    child_set.append(child)          
            #explore children.
            for child_node in child_set:              
                #check if this node has already been explored.
                for complete_child in complete_set:
                    if child_node == complete_child:
                        continue
                #generates child node values.
                child_node.step_count = explore_node.step_count + 1
                child_node.heuristic = ((child_node.position[0] - end_node.position[0]) ** 2) + ((child_node.position[1] - end_node.position[1]) ** 2)
                child_node.pos_val = child_node.step_count + child_node.heuristic
                # checks if the child_node is already in the explore set.
                for explore_node in explore_set:
                    if child_node == explore_node and child_node.step_count > explore_node.step_count:
                        continue
                # Add the child_node to the explore set.
                explore_set.append(child_node)
        pass

    # Part 2.1: Load map (map.npy) from disk and visualize it
    the_map = np.load("map.npy")
    the_map = np.rot90(the_map,k=3)
    plt.imshow(the_map)
    #plt.show()

    
    # Part 2.2: Compute an approximation of the “configuration space”
    for _ in range(5):
        obs = []
        for y in range(len(the_map)):
            for x in range(len(the_map[0])):
                if the_map[y][x] == 1:
                    obs.append([y,x]) #row,col
        for x in obs:
            row = x[0]
            col = x[1]
            count = 0
            if row+1 < 360 and the_map[row+1][col] == 1:
                count += 1
            if row-1 >= 0 and the_map[row-1][col] == 1:   
                    count += 1
            if col+1 < 360 and the_map[row][col+1] == 1:
                    count += 1
            if col-1 >= 0 and the_map[row][col-1] == 1:
                    count += 1
            if row+1 < 360 and col+1 < 360 and the_map[row+1][col+1] == 1:
                    count += 1
            if row-1 >= 0 and col-1 >= 0 and the_map[row-1][col-1] == 1:   
                    count += 1
            if row-1 >= 0 and col+1 < 360 and the_map[row-1][col+1] == 1:
                    count += 1
            if row+1 < 360 and col-1 >= 0 and the_map[row+1][col-1] == 1:
                    count += 1
            
            if count > 4:
                if row+1 < 360:
                    the_map[row+1][col] = 1
                if row-1 >= 0:   
                    the_map[row-1][col] = 1
                if col+1 < 360:
                    the_map[row][col+1] = 1
                if col-1 >= 0:
                    the_map[row][col-1] = 1
                
                if row+1 < 360 and col+1 < 360:
                    the_map[row+1][col+1] = 1
                if row-1 >= 0 and col-1 >= 0:   
                    the_map[row-1][col-1] = 1
                if row-1 >= 0 and col+1 < 360:
                    the_map[row-1][col+1] = 1
                if row+1 < 360 and col-1 >= 0:
                    the_map[row+1][col-1] = 1
            elif count <= 2:
                the_map[row][col] = 0
                
            
    plt.imshow(the_map)
    #plt.show()
    # Part 2.3 continuation: Call path_planner
    print("here4",flush = True)
    sys.stdout.flush()
    the_path = path_planner(the_map, start, end)

    # Part 2.4: Turn paths into waypoints and save on disk as path.npy and visualize it
    waypoints = []

######################
#
# Map Initialization
#
######################

# Part 1.2: Map Initialization

# Initialize your map data structure here as a 2D floating point array
map = np.zeros([360,360], dtype=float)
waypoints = []

if mode == 'autonomous':
    # Part 3.1: Load path from disk and visualize it
    waypoints = [] # Replace with code to load your path

state = 0 # use this to iterate through your path




while robot.step(timestep) != -1 and mode != 'planner':

    ###################
    #
    # Mapping
    #
    ###################

    ################ v [Begin] Do not modify v ##################
    # Ground truth pose
    pose_y = gps.getValues()[2]
    pose_x = gps.getValues()[0]

    n = compass.getValues()
    rad = -((math.atan2(n[0], n[2]))-1.5708)
    pose_theta = rad

    lidar_sensor_readings = lidar.getRangeImage()
    lidar_sensor_readings = lidar_sensor_readings[83:len(lidar_sensor_readings)-83]

    for i, rho in enumerate(lidar_sensor_readings):
        alpha = lidar_offsets[i]

        if rho > LIDAR_SENSOR_MAX_RANGE:
            continue

        # The Webots coordinate system doesn't match the robot-centric axes we're used to
        rx = math.cos(alpha)*rho
        ry = -math.sin(alpha)*rho

        # Convert detection from robot coordinates into world coordinates
        wx =  math.cos(pose_theta)*rx - math.sin(pose_theta)*ry + pose_x
        wy =  -(math.sin(pose_theta)*rx + math.cos(pose_theta)*ry) + pose_y
    
        ################ ^ [End] Do not modify ^ ##################

        #print("Rho: %f Alpha: %f rx: %f ry: %f wx: %f wy: %f" % (rho,alpha,rx,ry,wx,wy))
        #print(360-int(wy*30), int(wx*30))
        if rho < LIDAR_SENSOR_MAX_RANGE:
            # Part 1.3: visualize map gray values.
            if 360-int(wy*30) < 360 and int(wx*30) < 360:
                #increments the map reading values by a small amount.
                map[360-int(wy*30)][int(wx*30)] += SMALL_MAP_INCREMENT_CONSTANT
                map[360-int(wy*30)][int(wx*30)] = min(1,map[360-int(wy*30)][int(wx*30)])
                #converts into a useable grey scale value for drawing.
                cell_val = int(map[360-int(wy*30)][int(wx*30)] * 255)
                map_color = cell_val*256**2+cell_val*256+cell_val
                
                # finally print values
                display.setColor(map_color)
                display.drawPixel(360-int(wy*30),int(wx*30))

    # Draw the robot's current pose on the 360x360 display
    display.setColor(int(0xFF0000))
    display.drawPixel(360-int(pose_y*30),int(pose_x*30))



    ###################
    #
    # Controller
    #
    ###################
    if mode == 'manual':
        key = keyboard.getKey()
        while(keyboard.getKey() != -1): pass
        if key == keyboard.LEFT :
            vL = -MAX_SPEED
            vR = MAX_SPEED
        elif key == keyboard.RIGHT:
            vL = MAX_SPEED
            vR = -MAX_SPEED
        elif key == keyboard.UP:
            vL = MAX_SPEED
            vR = MAX_SPEED
        elif key == keyboard.DOWN:
            vL = -MAX_SPEED
            vR = -MAX_SPEED
        elif key == ord(' '):
            vL = 0
            vR = 0
        elif key == ord('S'):
            # Part 1.4: Filter map and save to filesystem
            np.save("map.npy",np.where(map > 0.5 , 1, 0))
            print("Map file saved")
        elif key == ord('L'):
            # You will not use this portion in Part 1 but here's an example for loading saved a numpy array
            map = np.load("map.npy")
            print("Map loaded")
        else: # slow down
            vL *= 0.75
            vR *= 0.75
    else: # not manual mode
        # Part 3.2: Feedback controller
        #STEP 1: Calculate the error
        rho = 0
        alpha = -(math.atan2(waypoint[state][1]-pose_y,waypoint[state][0]-pose_x) + pose_theta)


        #STEP 2: Controller
        dX = 0
        dTheta = 0

        #STEP 3: Compute wheelspeeds
        vL = 0
        vR = 0

        # Normalize wheelspeed
        # (Keep the wheel speeds a bit less than the actual platform MAX_SPEED to minimize jerk)


    # Odometry code. Don't change vL or vR speeds after this line.
    # We are using GPS and compass for this lab to get a better pose but this is how you'll do the odometry
    pose_x += (vL+vR)/2/MAX_SPEED*MAX_SPEED_MS*timestep/1000.0*math.cos(pose_theta)
    pose_y -= (vL+vR)/2/MAX_SPEED*MAX_SPEED_MS*timestep/1000.0*math.sin(pose_theta)
    pose_theta += (vR-vL)/AXLE_LENGTH/MAX_SPEED*MAX_SPEED_MS*timestep/1000.0

    # print("X: %f Z: %f Theta: %f" % (pose_x, pose_y, pose_theta))

    # Actuator commands
    robot_parts[MOTOR_LEFT].setVelocity(vL)
    robot_parts[MOTOR_RIGHT].setVelocity(vR)